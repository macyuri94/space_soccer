package aula5.example.spacesoccer.views

// << ---------------------------------------------------------------------------------------------------------------- >> //

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import aula5.example.spacesoccer.R
import kotlinx.android.synthetic.*

// << ---------------------------------------------------------------------------------------------------------------- >> //

class CriarEquipaActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.criar_equipa)


    }
}
