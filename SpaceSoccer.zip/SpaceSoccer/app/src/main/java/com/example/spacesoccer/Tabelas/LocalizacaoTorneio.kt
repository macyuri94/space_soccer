package com.example.spacesoccer.Tabelas

import org.json.JSONObject

class LocalizacaoTorneio {


    var IdLocalizacao: Long? = null
    var Pais: String? = null
    var Cidade: String? = null
    var CoordenadaX: Long? = null
    var CoordenadaY: Long? = null
    var Informacao: String? = null



    constructor(
        IdLocalizacao: Long?,
        Pais: String?,
        Cidade: String?,
        CoordenadaX: Long?,
        CoordenadaY: Long?,
        Informacao: String?

    ) {
        this.IdLocalizacao = IdLocalizacao
        this.Pais = Pais
        this.Cidade = Cidade
        this.CoordenadaX = CoordenadaX
        this.CoordenadaY = CoordenadaY
        this.Informacao = Informacao

    }

    constructor() {}

    fun toJson(): JSONObject {
        val jsonObject: JSONObject = JSONObject()
        jsonObject.put("IdLocalizacao", IdLocalizacao)
        jsonObject.put("Pais", Pais)
        jsonObject.put("Cidade", Cidade)
        jsonObject.put("CoordenadaX", CoordenadaX)
        jsonObject.put("CoordenadaY", CoordenadaY)
        jsonObject.put("Informacao", Informacao)



        return jsonObject
    }

    companion object {
        fun parseJson(jsonArticle: JSONObject): LocalizacaoTorneio {
            val LocalizacaoTorneio = LocalizacaoTorneio()

            LocalizacaoTorneio.IdLocalizacao = jsonArticle.getLong("IdLocalizacao")
            LocalizacaoTorneio.Pais = jsonArticle.getString("Pais")
            LocalizacaoTorneio.Cidade = jsonArticle.getString("Cidade")
            LocalizacaoTorneio.CoordenadaX = jsonArticle.getLong("CoordenadaX")
            LocalizacaoTorneio.CoordenadaY = jsonArticle.getLong("CoordenadaY")
            LocalizacaoTorneio.Informacao = jsonArticle.getString("Informacao")


            return LocalizacaoTorneio
        }
    }

}

//
//create table LocalizacaoTorneio (
//IdLocalizacao int primary key,
//Pais varchar(50) not null,
//Cidade varchar(50) not null,
//CoordenadaX int not null,
//CoordenadaY int not null,
//Informacao text not null) ;