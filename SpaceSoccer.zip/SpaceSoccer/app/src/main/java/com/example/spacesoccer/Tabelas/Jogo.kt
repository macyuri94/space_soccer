package com.example.spacesoccer.Tabelas

import org.json.JSONObject

class Jogo {


    var IdJogo: Long? = null
    var Arbitro: String? = null
    var segundoArbitro: String? = null
    var VideoArbitro: String? = null
    var TempoJogo: Long? = null
    var DataJogo: Long? = null



    constructor(
        IdJogo: Long?,
        Arbitro: String?,
        segundoArbitro: String?,
        VideoArbitro: String?,
        TempoJogo: Long?,
        DataJogo: Long?

    ) {
        this.IdJogo = IdJogo
        this.Arbitro = Arbitro
        this.segundoArbitro = segundoArbitro
        this.VideoArbitro = VideoArbitro
        this.TempoJogo = TempoJogo
        this.DataJogo = DataJogo

    }

    constructor() {}

    fun toJson(): JSONObject {
        val jsonObject: JSONObject = JSONObject()
        jsonObject.put("IdJogo", IdJogo)
        jsonObject.put("Arbitro", Arbitro)
        jsonObject.put("segundoArbitro", segundoArbitro)
        jsonObject.put("VideoArbitro", VideoArbitro)
        jsonObject.put("TempoJogo", TempoJogo)
        jsonObject.put("DataJogo", DataJogo)



        return jsonObject
    }

    companion object {
        fun parseJson(jsonArticle: JSONObject): Jogo {
            val Jogo = Jogo()

            Jogo.IdJogo = jsonArticle.getLong("IdJogo")
            Jogo.Arbitro = jsonArticle.getString("Arbitro")
            Jogo.segundoArbitro = jsonArticle.getString("segundoArbitro")
            Jogo.VideoArbitro = jsonArticle.getString("VideoArbitro")
            Jogo.TempoJogo = jsonArticle.getLong("TempoJogo")
            Jogo.DataJogo = jsonArticle.getLong("DataJogo")


            return Jogo
        }
    }

}

//Create table Jogo (
//IdJogo int primary key ,
//Arbitro varchar(40) not null,
//segundoArbitro varchar(40),
//VideoArbitro varchar(40),
//TempoJogo int ,
//DataJogo datetime not null,
//
//
//
//
//
//Torneio int REFERENCES  Torneio (IdTorneio) ,		--chave estrangeira do torneio
//Incidencias int REFERENCES Incidencia(idIncidencia)  , 	--chave estrangeira das INCIDENCIAS
//Estatistica int REFERENCES Estatisticas (IdEstatistica)     --chave estrangeira da estatistica
//);