package com.example.spacesoccer

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Query

class Login {




}


