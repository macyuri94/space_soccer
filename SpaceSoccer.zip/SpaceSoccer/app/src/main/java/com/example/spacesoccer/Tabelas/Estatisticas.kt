package com.example.spacesoccer.Tabelas

import org.json.JSONObject

class Estatisticas {
    var IdEstatistica: Long? = null
    var PossedebolaHome: Long? = null
    var RematesABalizaHome: Long? = null
    var RematesABalizaAway: Long? = null
    var NumIncidenciasHome: Long? = null
    var NumIncidenciasAway: Long? = null
    var Golos_Away: Long? = null
    var Golos_Home: Long? = null
    var EquipaAway: Long? = null


    constructor(
        IdEstatistica: Long?,
        PossedebolaHome: Long?,
        RematesABalizaHome: Long?,
        RematesABalizaAway: Long?,
        NumIncidenciasHome: Long?,
        NumIncidenciasAway: Long?,
        Golos_Away: Long?,
        Golos_Home: Long?,
        EquipaAway: Long?
    ) {
        this.IdEstatistica = IdEstatistica
        this.PossedebolaHome = PossedebolaHome
        this.RematesABalizaHome = RematesABalizaHome
        this.RematesABalizaAway = RematesABalizaAway
        this.NumIncidenciasHome = NumIncidenciasHome
        this.NumIncidenciasAway = NumIncidenciasAway
        this.Golos_Away = Golos_Away
        this.Golos_Home = Golos_Home
        this.EquipaAway = EquipaAway
    }

    constructor() {}

    fun toJson(): JSONObject {
        val jsonObject: JSONObject = JSONObject()
        jsonObject.put("IdEstatistica", IdEstatistica)
        jsonObject.put("PossedebolaHome", PossedebolaHome)
        jsonObject.put("RematesABalizaHome", RematesABalizaHome)
        jsonObject.put("RematesABalizaAway", RematesABalizaAway)
        jsonObject.put("NumIncidenciasHome", NumIncidenciasHome)
        jsonObject.put("NumIncidenciasAway", NumIncidenciasAway)
        jsonObject.put("Golos_Away", Golos_Away)
        jsonObject.put("Golos_Home", Golos_Home)
        jsonObject.put("EquipaAway", EquipaAway)


        return jsonObject
    }

    companion object {
        fun parseJson(jsonArticle: JSONObject): Estatisticas {
            val Estatisticas = Estatisticas()

            Estatisticas.IdEstatistica = jsonArticle.getLong("IdEstatistica")
            Estatisticas.PossedebolaHome = jsonArticle.getLong("PossedebolaHome")
            Estatisticas.RematesABalizaHome = jsonArticle.getLong("RematesABalizaHome")
            Estatisticas.RematesABalizaAway = jsonArticle.getLong("RematesABalizaAway")
            Estatisticas.NumIncidenciasHome = jsonArticle.getLong("NumIncidenciasHome")
            Estatisticas.NumIncidenciasAway = jsonArticle.getLong("NumIncidenciasAway")
            Estatisticas.Golos_Away = jsonArticle.getLong("Golos_Away")
            Estatisticas.Golos_Home = jsonArticle.getLong("Golos_Home")
            Estatisticas.EquipaAway = jsonArticle.getLong("EquipaAway")
            return Estatisticas
        }
    }
}

//create table Estatisticas (
// IdEstatistica int primary key ,
//PossedebolaHome int not null,

//RematesABalizaHome int not null,

//RematesABalizaAway int not null,

//NumIncidenciasHome int not null,
//NumIncidenciasÃway int not null,

//Golos_Away int not null,
//Golos_Home int not null,
//EquipaHome varchar(30) not null,
//EquipaAway varchar(30) not null
//);