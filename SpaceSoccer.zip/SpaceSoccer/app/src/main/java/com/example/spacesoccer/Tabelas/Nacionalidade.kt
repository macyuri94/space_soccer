package com.example.spacesoccer.Tabelas

import org.json.JSONObject





    class Nacionalidade {

        var IdNacionalidade : Long ? = null
        var NomeNacionalidade : String ? = null
        var Sigla : String ? = null




        constructor(
            IdNacionalidade: Long?,
            NomeNacionalidade: String?,
            Sigla: String?

        )
        {
            this.IdNacionalidade = IdNacionalidade
            this.NomeNacionalidade = NomeNacionalidade
            this.Sigla   = Sigla

        }

        constructor(){}

        fun toJson () : JSONObject {
            val jsonObject : JSONObject = JSONObject()
            jsonObject.put("IdNacionalidade"              , IdNacionalidade              )
            jsonObject.put("NomeNacionalidade"            , NomeNacionalidade            )
            jsonObject.put("Sigla"          , Sigla          )



            return  jsonObject
        }

        companion object {
            fun parseJson(jsonArticle: JSONObject) : Nacionalidade {
                val Nacionalidade = Nacionalidade ()

                Nacionalidade.IdNacionalidade               = jsonArticle.getLong  ("IdNacionalidade"               )
                Nacionalidade.NomeNacionalidade             = jsonArticle.getString("NomeNacionalidade"             )
                Nacionalidade.Sigla           = jsonArticle.getString("Sigla"           )


                return Nacionalidade
            }
        }






//
//    --Tabela Jogadores
//    create table Jogadores (CodAcesso  int not null,
//    IdJogador int identity (1,1) Primary Key,
//    Nome varchar(40) not null,
//    NumCamisola int not null,
//    Email varchar(40) not null,
//    Idade int not null,
//    Nacionalidade int not null REFERENCES Nacionalidade(IdNacionalidade) , --chave estrangeira da Nacionalidades
//    Posicao int  not null REFERENCES Posicao(IDPosicao), --chave estrangeira da posicao
//    Altura int not null,
//    Peso int,
//    Clube int REFERENCES Clube(IdClube), --chave estrangeira do clube
//    NivelAcesso int not null);

    }
