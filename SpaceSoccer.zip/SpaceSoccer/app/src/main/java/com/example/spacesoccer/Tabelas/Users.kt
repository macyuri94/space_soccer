package com.example.spacesoccer.Tabelas

import org.json.JSONObject
import java.util.*

class Users {

    var CC: Long? = null
    var Nome: String? = null
    var DataNascimento: Long? = null
    var NumTelemovel: Long? = null
    var Email: String? = null
    var Username: String? = null
    var Passwordd: String? = null


    constructor(
        CC: Long?,
        Nome: String?,
        DataNascimento: Long?,
        NumTelemovel: Long?,
        Email: String?,
        Username: String?,
        Passwordd: String?
    ) {
        this.CC = CC
        this.Nome = Nome
        this.DataNascimento = DataNascimento
        this.NumTelemovel = NumTelemovel
        this.Email = Email
        this.Username = Username
        this.Passwordd = Passwordd

    }

    constructor() {}

    fun toJson(): JSONObject {
        val jsonObject: JSONObject = JSONObject()
        jsonObject.put("CC", CC)
        jsonObject.put("Nome", Nome)
        jsonObject.put("DataNascimento", DataNascimento)
        jsonObject.put("NumTelemovel", NumTelemovel)
        jsonObject.put("Email", Email)
        jsonObject.put("Username", Username)
        jsonObject.put("Passwordd", Passwordd)



        return jsonObject
    }

    companion object {
        fun parseJson(jsonArticle: JSONObject): Users {
            val Users = Users()

            Users.CC = jsonArticle.getLong("CC")
            Users.Nome = jsonArticle.getString("Nome")
            Users.DataNascimento = jsonArticle.getLong("DataNascimento")
            Users.NumTelemovel = jsonArticle.getLong("NumTelemovel")
            Users.Email = jsonArticle.getString("Email")
            Users.Username = jsonArticle.getString("Username")
            Users.Passwordd = jsonArticle.getString("Passwordd")


            return Users
        }


    }
}



//
//    create table Users  (
//
//    CC int Primary key not null,
//    Nome varchar(30) not null,
//    DataNascimento datetime not null,
//    NumTelemovel int(9) not null,
//    Email varchar(40) not null unique ,
//    Username varchar(40) not null unique ,
//    Passwordd varchar(30) ,
//    FkCargo int not null
//
//    )