package com.example.spacesoccer.Tabelas

import org.json.JSONObject

class Estadio {


    var IdEstadio: Long? = null
    var Nome: String? = null
    var NumLugares: Long? = null
    var Cidade: String? = null
    var Historia: String? = null


    constructor(
        IdEstadio: Long?,
        Nome: String?,
        NumLugares: Long?,
        Cidade: String?,
        Historia: String?

    ) {
        this.IdEstadio = IdEstadio
        this.Nome = Nome
        this.NumLugares = NumLugares
        this.Cidade = Cidade
        this.Historia = Historia

    }

    constructor() {}

    fun toJson(): JSONObject {
        val jsonObject: JSONObject = JSONObject()
        jsonObject.put("IdEstadio", IdEstadio)
        jsonObject.put("Nome", Nome)
        jsonObject.put("NumLugares", NumLugares)
        jsonObject.put("Cidade", Cidade)
        jsonObject.put("Historia", Historia)



        return jsonObject
    }

    companion object {
        fun parseJson(jsonArticle: JSONObject): Estadio {
            val Estadio = Estadio()

            Estadio.IdEstadio = jsonArticle.getLong("IdEstadio")
            Estadio.Nome = jsonArticle.getString("Nome")
            Estadio.NumLugares = jsonArticle.getLong("NumLugares")
            Estadio.Cidade = jsonArticle.getString("Cidade")
            Estadio.Historia = jsonArticle.getString("Historia")


            return Estadio
        }
    }
}



//create table Estadio (IdEstadio int primary key,
////Nome varchar(30) not null,
////NumLugares int not null,
////Cidade varchar(30) not null,
////Historia text );