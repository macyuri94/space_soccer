package com.example.spacesoccer.Tabelas

import org.json.JSONObject

class Torneio {

    var CodAIdTorneiocesso: Long? = null
    var Nome: String? = null
    var dtInicio: Long? = null
    var dtFim: Long? = null
    var Campeao: String? = null
    var NumEquipas: Long? = null
    var Categoria: String? = null
    var TipoCompeticao: String? = null
    var NumParticipantes: Long? = null


    constructor(
        CodAIdTorneiocesso: Long?,
        Nome: String?,
        dtInicio: Long?,
        dtFim: Long?,
        Campeao: String?,
        NumEquipas: Long?,
        Categoria: String?,
        TipoCompeticao: String?,
        NumParticipantes: Long?
    ) {
        this.CodAIdTorneiocesso = CodAIdTorneiocesso
        this.Nome = Nome
        this.dtInicio = dtInicio
        this.dtFim = dtFim
        this.Campeao = Campeao
        this.NumEquipas = NumEquipas
        this.Categoria = Categoria
        this.TipoCompeticao = TipoCompeticao
        this.NumParticipantes = NumParticipantes
    }

    constructor() {}

    fun toJson(): JSONObject {
        val jsonObject: JSONObject = JSONObject()
        jsonObject.put("CodAIdTorneiocesso", CodAIdTorneiocesso)
        jsonObject.put("Nome", Nome)
        jsonObject.put("dtInicio", dtInicio)
        jsonObject.put("dtFim", dtFim)
        jsonObject.put("Campeao", Campeao)
        jsonObject.put("NumEquipas", NumEquipas)
        jsonObject.put("Categoria", Categoria)
        jsonObject.put("TipoCompeticao", TipoCompeticao)
        jsonObject.put("NumParticipantes", NumParticipantes)


        return jsonObject
    }

    companion object {
        fun parseJson(jsonArticle: JSONObject): Torneio {
            val Torneio = Torneio()

            Torneio.CodAIdTorneiocesso = jsonArticle.getLong("CodAIdTorneiocesso")
            Torneio.Nome = jsonArticle.getString("Nome")
            Torneio.dtInicio = jsonArticle.getLong("dtInicio")
            Torneio.dtFim = jsonArticle.getLong("dtFim")
            Torneio.Campeao = jsonArticle.getString("Campeao")
            Torneio.NumEquipas = jsonArticle.getLong("NumEquipas")
            Torneio.Categoria = jsonArticle.getString("Categoria")
            Torneio.TipoCompeticao = jsonArticle.getString("TipoCompeticao")
            Torneio.NumParticipantes = jsonArticle.getLong("NumParticipantes")
            return Torneio
        }
    }
}

//create table Torneio (
//IdTorneio int primary key ,
//Nome varchar(40) not null,
//dtInicio datetime not null,
//dtFim datetime not null,
//Campeao varchar(30) ,
//NumEquipas int not null,
//Clubes int REFERENCES Clube(IdClube) , --chave estrangeira dos clubes
//NumGrupos int not null,
//Categoria varchar(3) not null,
//TipoCompeticao varchar(30) not null,
//NumParticipantes int not null,
//Localizacao  int not null REFERENCES LocalizacaoTorneio(IdLocalizacao)  --chave estrangeira da localizacao
//);