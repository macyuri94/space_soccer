package com.example.spacesoccer.Tabelas

import org.json.JSONObject

class Cargo {

    var IdCargo: Long? = null
    var Cargo: String? = null
    var NivelAcesso: Long? = null



    constructor(
        IdCargo: Long?,
        Cargo: String?,
        NivelAcesso: Long?


    ) {
        this.IdCargo = IdCargo
        this.Cargo = Cargo
        this.NivelAcesso = NivelAcesso


    }

    constructor() {}

    fun toJson(): JSONObject {
        val jsonObject: JSONObject = JSONObject()
        jsonObject.put("IdCargo", IdCargo)
        jsonObject.put("Cargo", Cargo)
        jsonObject.put("NivelAcesso", NivelAcesso)




        return jsonObject
    }

    companion object {
        fun parseJson(jsonArticle: JSONObject): Cargo {
            val Cargo = Cargo()

            Cargo.IdCargo = jsonArticle.getLong("IdCargo")
            Cargo.Cargo = jsonArticle.getString("Cargo")
            Cargo.NivelAcesso = jsonArticle.getLong("NivelAcesso")



            return Cargo
        }
    }
}


//
//create table Cargo (
//IdCargo int primary key not null
//Cargo varchar(20) not null,
//NivelAcesso int not null ,
//FkClube int not null
//
//);