package com.example.spacesoccer.Tabelas

import org.json.JSONObject

class Cartao {
    var idCartao: Long? = null
    var CorCartao: String? = null
    var NivelAcesso: Long? = null



    constructor(
        idCartao: Long?,
        CorCartao: String?



    ) {
        this.idCartao = idCartao
        this.CorCartao = CorCartao



    }

    constructor() {}

    fun toJson(): JSONObject {
        val jsonObject: JSONObject = JSONObject()
        jsonObject.put("IdCargo", idCartao)
        jsonObject.put("CorCartao", CorCartao)





        return jsonObject
    }

    companion object {
        fun parseJson(jsonArticle: JSONObject): Cartao {
            val Cartao = Cartao()

            Cartao.idCartao = jsonArticle.getLong("idCartao")
            Cartao.CorCartao = jsonArticle.getString("CorCartao")




            return Cartao
        }
    }

}


//create table Cartao (
//
//idCartao int primary key,
//CorCartao varchar(8) not null ,
//
//);