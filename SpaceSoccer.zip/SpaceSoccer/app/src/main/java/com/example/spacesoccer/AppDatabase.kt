package com.example.spacesoccer

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import javax.security.auth.login.LoginException

class AppDatabase {
    @Database(entities = [User::class], version = 1)
    abstract class AppDatabase : RoomDatabase() {
        abstract fun userDao(): UserDao

    }



    val db = Room.databaseBuilder(
         applicationContext,
        AppDatabase::class.java, "SpaceSoccerv1"
    ).build()

//    val db = Room.databaseBuilder(
//        applicationContext,
//        AppDatabase::class.java, "database-name"
//    ).build()




}




// 192.168.1.80
// SpaceSoccerv1