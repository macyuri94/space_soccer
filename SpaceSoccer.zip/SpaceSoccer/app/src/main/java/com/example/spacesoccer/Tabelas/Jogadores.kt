package com.example.spacesoccer.Tabelas

import org.json.JSONObject

class Jogadores {

    var CodAcesso : Long ? = null
    var IdJogador : Long ? = null
    var Nome : String ? = null
    var NumCamisola : Long ? = null
    var Email : String ? = null
    var Idade : Long ? = null
    var Altura : Long ? = null
    var Peso : Long ? = null
    var NivelAcesso : Long ? = null



            constructor(
                CodAcesso: Long?,
                IdJogador: Long?,
                Nome: String?,
                NumCamisola: Long?,
                Email: String?,
                Idade: Long?,
                Altura: Long?,
                Peso: Long?,
                NivelAcesso: Long?
    )
            {
                this.CodAcesso = CodAcesso
                this.IdJogador = IdJogador
                this.Nome   = Nome
                this.NumCamisola = NumCamisola
                this.Email = Email
                this.Idade = Idade
                this.Altura = Altura
                this.Peso = Peso
                this.NivelAcesso = NivelAcesso
}

    constructor(){}

    fun toJson () : JSONObject {
        val jsonObject : JSONObject = JSONObject()
        jsonObject.put("CodAcesso"              , CodAcesso              )
        jsonObject.put("IdJogador"            , IdJogador            )
        jsonObject.put("Nome"          , Nome          )
        jsonObject.put("NumCamisola"      , NumCamisola      )
        jsonObject.put("Email"  , Email  )
        jsonObject.put("Idade", Idade)
        jsonObject.put("Altura" , Altura )
        jsonObject.put("Peso" , Peso )
        jsonObject.put("NivelAcesso" , NivelAcesso )


        return  jsonObject
    }

    companion object {
        fun parseJson(jsonArticle: JSONObject) : Jogadores {
            val Jogadores = Jogadores ()

            Jogadores.CodAcesso               = jsonArticle.getLong  ("CodAcesso"               )
            Jogadores.IdJogador             = jsonArticle.getLong("IdJogador"             )
            Jogadores.Nome           = jsonArticle.getString("Nome"           )
            Jogadores.NumCamisola       = jsonArticle.getLong("NumCamisola"       )
            Jogadores.Email   = jsonArticle.getString("Email"   )
            Jogadores.Idade = jsonArticle.getLong("Idade" )
            Jogadores.Altura  = jsonArticle.getLong("Altura"  )
            Jogadores.Peso  = jsonArticle.getLong("Peso"  )
            Jogadores.NivelAcesso  = jsonArticle.getLong("NivelAcesso"  )

            return Jogadores
        }
    }






//
//    --Tabela Jogadores
//    create table Jogadores (CodAcesso  int not null,
//    IdJogador int identity (1,1) Primary Key,
//    Nome varchar(40) not null,
//    NumCamisola int not null,
//    Email varchar(40) not null,
//    Idade int not null,
//    Nacionalidade int not null REFERENCES Nacionalidade(IdNacionalidade) , --chave estrangeira da Nacionalidades
//    Posicao int  not null REFERENCES Posicao(IDPosicao), --chave estrangeira da posicao
//    Altura int not null,
//    Peso int,
//    Clube int REFERENCES Clube(IdClube), --chave estrangeira do clube
//    NivelAcesso int not null);

}