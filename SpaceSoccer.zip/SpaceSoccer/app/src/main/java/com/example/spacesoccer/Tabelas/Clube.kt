package com.example.spacesoccer.Tabelas

import android.media.Image
import org.json.JSONObject

class Clube {

    var IdClube: Long? = null
    var Presidente: String? = null
    var AnoFundacao: Long? = null
    var CidadeFundacao: String? = null
    var Logotipo: Long? = null


    constructor(
        IdClube: Long?,
        Presidente: String?,
        AnoFundacao: Long?,
        CidadeFundacao: String?,
        Logotipo: Long?

    ) {
        this.IdClube = IdClube
        this.Presidente = Presidente
        this.AnoFundacao = AnoFundacao
        this.CidadeFundacao = CidadeFundacao
        this.Logotipo = Logotipo

    }

    constructor() {}

    fun toJson(): JSONObject {
        val jsonObject: JSONObject = JSONObject()
        jsonObject.put("IdClube", IdClube)
        jsonObject.put("Presidente", Presidente)
        jsonObject.put("AnoFundacao", AnoFundacao)
        jsonObject.put("CidadeFundacao", CidadeFundacao)
        jsonObject.put("Logotipo", Logotipo)



        return jsonObject
    }

    companion object {
        fun parseJson(jsonArticle: JSONObject): Clube {
            val Clube = Clube()

            Clube.IdClube = jsonArticle.getLong("IdEstadio")
            Clube.Presidente = jsonArticle.getString("Nome")
            Clube.AnoFundacao = jsonArticle.getLong("NumLugares")
            Clube.CidadeFundacao = jsonArticle.getString("Cidade")
            Clube.Logotipo = jsonArticle.getLong("Historia")


            return Clube
        }
    }
}

//create table Clube (
//IdClube int  primary key,
//Presidente varchar(40) not null ,
//AnoFundacao datetime  not null,
//CidadeFundacao varchar(40) not null,
//Logotipo image not null,
//)
//PORTOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
//FUCK FLAMENGO
