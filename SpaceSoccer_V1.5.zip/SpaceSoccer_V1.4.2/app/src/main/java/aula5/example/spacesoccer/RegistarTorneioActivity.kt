package aula5.example.spacesoccer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class RegistarTorneioActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_space_soccer_registar_torneio)
    }
}
